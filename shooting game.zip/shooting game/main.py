# Import the pygame module
import pygame

# Import random for random numbers
import random
import math

running = True
while running:
    for event in pygame.event.get():
        pass

